import "./index.css";

const Form = ({ children }) => {
    return <div className="form">{children}</div>;
};

export default Form;
